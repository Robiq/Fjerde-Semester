#!/bin/sh
java -jar irvtool.jar